angular-content-grid
====================

Content grid (using Masonry) integration with Angular.JS
