function WidgetController ($scope) {
  $scope.tweets = [];//loaded from JSON data above
}